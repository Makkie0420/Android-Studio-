package com.example.android18;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.Switch;


public class Activitymain extends AppCompatActivity {
    private ToggleButton toggleButton1, toggleButton2;
    private Switch Switch1, Switch2;
    private TextView txt1, txt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activitymain);
        toggleButton1=(ToggleButton)findViewById(R.id.toggleButton1);
        toggleButton2=(ToggleButton)findViewById(R.id.toggleButton2);
        Switch1=(Switch)findViewById(R.id.switch1);
        Switch2=(Switch)findViewById(R.id.switch2);
        txt1=(TextView)findViewById(R.id.txt1);
        txt2=(TextView)findViewById(R.id.txt2);


    }
    public void toastClick(View view) {

        LayoutInflater Li = getLayoutInflater();

        View layout = Li.inflate(R.layout.customtoast,(ViewGroup) findViewById(R.id.custom_toast_layout));

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setView(layout);
        toast.show();

        if (Switch1.isChecked()) {
            // if switch is checked.
            txt1.setText("Switch 1 is " + Switch1.getTextOn().toString());
            Toast.makeText(getApplicationContext(), "Switch 1 is " + Switch1.getTextOn().toString(), Toast.LENGTH_LONG).show();
        }
        else {
            // if switch is unchecked.
            txt1.setText("Switch 1 is " + Switch1.getTextOff().toString());
            Toast.makeText(getApplicationContext(), "Switch 1 is " + Switch1.getTextOff().toString(), Toast.LENGTH_LONG).show();
        }
        if (Switch2.isChecked()) {
            // if switch is checked.
            txt1.setText("Switch 2 is " + Switch2.getTextOn().toString());
            Toast.makeText(getApplicationContext(), "Switch 2 is " + Switch2.getTextOn().toString(), Toast.LENGTH_LONG).show();
        }
        else {
            // if switch is unchecked.
            txt1.setText("Switch 2 is " + Switch1.getTextOff().toString());
            Toast.makeText(getApplicationContext(), "Switch 2 is " + Switch2.getTextOff().toString(), Toast.LENGTH_LONG).show();
        }
    }


}