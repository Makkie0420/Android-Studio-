package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AccountRVAdapter extends RecyclerView.Adapter<AccountRVAdapter.ViewHolder> {
    // variable for our array list and context
    private ArrayList<ActivityModal> ModalArrayList;
    private Context context;

    // constructor
    public AccountRVAdapter(ArrayList<ActivityModal> ModalArrayList, Context context) {
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_account_rv, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // on below line we are setting data  to our views of recycler view item.
        ActivityModal modal = ModalArrayList.get(position);
        holder.NameTV.setText(modal.getName());
        holder.EmailTV.setText(modal.getEmail());
        holder.PassTV.setText(modal.getPass());
        holder.UsernameTV.setText(modal.getUsername());


        // below line is to add on click listener for our recycler view item.
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // on below line we are calling an intent.
                Intent i = new Intent(context, UpdateAccountsInfo.class);

                // below we are passing all our values.
                i.putExtra("name", modal.getName());
                i.putExtra("email", modal.getEmail());
                i.putExtra("pass", modal.getPass());
                i.putExtra("username", modal.getUsername());


                // starting our activity.
                context.startActivity(i);
            }
        });


    }

    @Override
    public int getItemCount() {
        return ModalArrayList.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our text views.
        private TextView NameTV, EmailTV, PassTV, UsernameTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            NameTV = itemView.findViewById(R.id.tvName);
            EmailTV = itemView.findViewById(R.id.tvEmail);
            PassTV = itemView.findViewById(R.id.tvPass);
            UsernameTV = itemView.findViewById(R.id.tvUsername);


        }
    }
}
