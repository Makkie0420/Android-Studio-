package com.example.myapplication;

public class ActivityModal {

    private String Name;
    private String Email;
    private String Pass;
    private String Username;
    private String Gender;
    private int Id;


    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPass() {
        return Pass;
    }

    ;

    public void setPass(String Pass) {
        this.Pass = Pass;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        this.Id = id;
    } // constructor public

    ActivityModal(String Name, String Email, String Pass, String Username) {
        this.Name = Name;
        this.Email = Email;
        this.Pass = Pass;
        this.Username = Username;

    }
}