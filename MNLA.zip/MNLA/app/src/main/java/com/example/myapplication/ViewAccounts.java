package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import java.util.ArrayList;

public class ViewAccounts extends AppCompatActivity {
    private ArrayList<ActivityModal> ModalArrayList;
    private DBHandler dbHandler;
    private AccountRVAdapter RVAdapter;
    private RecyclerView RV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_accounts);

        ModalArrayList = new ArrayList<>(); dbHandler = new DBHandler(ViewAccounts.this);

        ModalArrayList = dbHandler.readStudents();

        RVAdapter = new AccountRVAdapter(ModalArrayList, ViewAccounts.this);
        RV = findViewById(R.id.idRV);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewAccounts.this, RecyclerView.VERTICAL, false);
        RV.setLayoutManager(linearLayoutManager);
        RV.setAdapter(RVAdapter);

    }
    public void btnBack (View view) {
        Intent i = new Intent(ViewAccounts.this, MainActivity.class);
        startActivity(i);
    }
}