package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText NameEdt, EmailEdt, PassEdt, UsernameEdt;
    private Button addBtn;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NameEdt = findViewById(R.id.LName);
        EmailEdt = findViewById(R.id.FName);
        PassEdt = findViewById(R.id.etPassword);
        UsernameEdt = findViewById(R.id.Email);
        addBtn = findViewById(R.id.btnAdd);


        dbHandler = new DBHandler(MainActivity.this);

    }
    public void btnClickAdd (View view) {
        // below line is to get data from all edit text fields.
        String Name = NameEdt.getText().toString();
        String Email = EmailEdt.getText().toString();
        String Pass = PassEdt.getText().toString();
        String Username = UsernameEdt.getText().toString();

        // validating if the text fields are empty or not.
        if (Name.isEmpty() || Email.isEmpty() || Pass.isEmpty() || Username.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter all the required data", Toast.LENGTH_SHORT).show();
            return;
        }
        dbHandler.addNew(Name, Email, Pass, Username);
        Toast.makeText(MainActivity.this, "Account has been created.",
                Toast.LENGTH_SHORT).show(); NameEdt.setText(""); EmailEdt.setText("");
       PassEdt.setText(""); UsernameEdt.setText("");

    }
    public void btnClickRead (View view) {
        // opening a new activity via a intent.
        Intent i = new Intent(MainActivity.this, ViewAccounts.class);
        startActivity(i);
    }
}

