package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateAccountsInfo extends AppCompatActivity {

    // variables for our edit text, button, strings and dbhandler class.
    private EditText NameEdt, EmailEdt, PassEdt, UsernameEdt;
    private Button updateCourseBtn;
    private DBHandler dbHandler;
    String Name, Email, Pass, Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_accounts_info);

        // initializing all our variables.
        NameEdt = findViewById(R.id.LName);
        EmailEdt = findViewById(R.id.FName);
        PassEdt = findViewById(R.id.etPassword);
        UsernameEdt = findViewById(R.id.Email);


        // on below line we are initializing our dbhandler class.
        dbHandler = new DBHandler(UpdateAccountsInfo.this);

        // on below lines we are getting data which
        // we passed in our adapter class.
        Name = getIntent().getStringExtra("name");
        Email = getIntent().getStringExtra("email");
        Pass = getIntent().getStringExtra("pass");
        Username = getIntent().getStringExtra("username");

        // setting data to edit text
        // of our update activity.
        NameEdt.setText(Name);
        EmailEdt.setText(Email);
        PassEdt.setText(Pass);
        UsernameEdt.setText(Username);


    }

    public void btnClickUpdate(View view)
    {
        // inside this method we are calling an update course
        // method and passing all our edit text values.
        dbHandler.update(Name, NameEdt.getText().toString(), EmailEdt.getText().toString(),
                PassEdt.getText().toString(), UsernameEdt.getText().toString());

        // displaying a toast message that our course has been updated.
        Toast.makeText(UpdateAccountsInfo.this, "Account Info Updated..", Toast.LENGTH_SHORT).show();

        // go bock to ViewStudents
        Intent i = new Intent(UpdateAccountsInfo.this, ViewAccounts.class);
        startActivity(i);
    }

    public void btnClickDelete (View view)
    {
        // calling a method to delete a student.
        dbHandler.delete(Name);
        Toast.makeText(UpdateAccountsInfo.this, "Deleted Account Data", Toast.LENGTH_SHORT).show();

        // go back to ViewStudents
        Intent i = new Intent(UpdateAccountsInfo.this, ViewAccounts.class);
        startActivity(i);
    }

    public void btnBack (View view) {
        Intent i = new Intent(UpdateAccountsInfo.this, MainActivity.class);
        startActivity(i);
    }
}
