package com.example.menu;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;



public class MachineActivity2 extends AppCompatActivity {


    private int total1, total2, total3, total4, total5, total6, total7, total8;
    private double totalamount = 0;
    private String pizza, burger, beverage, payment, size;
    private AlertDialog.Builder builder;
    private RadioGroup radiogroup1, radiogroup2, radiogroup3, radiogroup4, radiogroup5;
    private RadioButton radiobutton1, radiobutton2, radiobutton3, radiobutton4, radiobutton5;
    private TextView quantitiy1, quantitiy2, quantitiy3;
    private CheckBox chkbx1, chkbx2, chkbx3, chkbx4, chkbx5, chkbx6;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        chkbx1 = (CheckBox) findViewById(R.id.mushroom);
        chkbx2 = (CheckBox) findViewById(R.id.onions);
        chkbx3 = (CheckBox) findViewById(R.id.olives);
        chkbx4 = (CheckBox) findViewById(R.id.sausages);
        chkbx5 = (CheckBox) findViewById(R.id.pepperoni);
        chkbx6 = (CheckBox) findViewById(R.id.cheese);
        quantitiy1 = (TextView) findViewById(R.id.textview1);
        quantitiy2 = (TextView) findViewById(R.id.textview2);
        quantitiy3 = (TextView) findViewById(R.id.textview3);
        radiogroup1 = findViewById(R.id.pizza);
        radiogroup2 = findViewById(R.id.burger);
        radiogroup3 = findViewById(R.id.beverage);
        radiogroup4 = findViewById(R.id.size);
        radiogroup5 = findViewById(R.id.paymentBox);

        builder = new AlertDialog.Builder(this);
    }

    public void payBtn(View v) {
        StringBuilder result = new StringBuilder();
        builder.setMessage(result.append("You Ordered the following:"));

        int radioGroup1 = radiogroup1.getCheckedRadioButtonId();
        radiobutton1 = findViewById(radioGroup1);
        if (radioGroup1 == -1) {
            pizza = "";
        } else if (radioGroup1 == R.id.smallp) {
            pizza = "Small ";
            total2 += 75;
        } else if (radioGroup1 == R.id.mediump) {
            pizza = "Medium ";
            total2 += 150;
        } else if (radioGroup1 == R.id.largep) {
            pizza = "Large ";
            total2 += 250;
        } else if (radioGroup1 == R.id.jumbop) {
            pizza = "Jumbo ";
            total2 += 400;
        }

        total3 = Integer.parseInt(quantitiy1.getText().toString());


        if (!quantitiy1.getText().toString().equals("") && !pizza.equals("") && radioGroup1 != -1) {
            if (total3 >= 1) {
                total2 = total2 * total3;
            }

            builder.setMessage(result.append("\n\n" + total3 + " " + pizza + "Pizza:               " + total2));
            builder.setMessage(result.append("\nWith the following Additional Toppings:"));


            if (chkbx1.isChecked()) {
                builder.setMessage(result.append("\nMushroom"));
                total4 += 20;
            }
            if (chkbx2.isChecked()) {
                builder.setMessage(result.append("\nOnion"));
                total4 += 20;
            }
            if (chkbx3.isChecked()) {
                builder.setMessage(result.append("\nOlive"));
                total4 += 20;
            }
            if (chkbx4.isChecked()) {
                builder.setMessage(result.append("\nSausage"));
                total4 += 20;
            }
            if (chkbx5.isChecked()) {
                builder.setMessage(result.append("\nPeperoni"));
                total4 += 20;
            }
            if (chkbx6.isChecked()) {
                builder.setMessage(result.append("\nMore Cheese"));
                total4 += 20;
            }

            total4 = total4 * total3;
            total2 += total4;

            result.append("\nAdditional toppings:      " + total4);
            result.append("\n" + total3 + " " + pizza + "Pizza (Total):                     " + total2);
        }

        int radBurger = radiogroup2.getCheckedRadioButtonId();
        radiobutton2 = findViewById(radBurger);

        if (radBurger == -1) {
            burger = "";
        } else if (radBurger == R.id.chicken) {
            burger = "Chicken ";
            total5 += 50;
        } else if (radBurger == R.id.beef) {
            burger = "Beef ";
            total5 += 75;
        } else if (radBurger == R.id.veg) {
            burger = "Vegetarian ";
            total5 += 60;
        }


        total6 = Integer.parseInt(quantitiy2.getText().toString());


        if (total6 >= 1) {
            total5 = total5 * total6;
        }
        result.append("\n\n" + total6 + " " + burger + "Burger (Total):                    " + total5);

        int radioGroup2 = radiogroup3.getCheckedRadioButtonId();
        radiobutton3 = findViewById(radioGroup2);
        int RadioGroup3 = radiogroup4.getCheckedRadioButtonId();
        radiobutton4 = findViewById(RadioGroup3);
        if (radioGroup2 == -1) {
            beverage = "";
        } else if (radioGroup2 == R.id.coke) {
            beverage = "Coke ";
            if (RadioGroup3 == R.id.reg) {
                total7 = 35;
                size = "Regular";
            } else if (RadioGroup3 == R.id.large) {
                total7 = 50;
                size = "Large";
            }
        } else if (radioGroup2 == R.id.sprite) {
            beverage = "Sprite ";
            if (RadioGroup3 == R.id.reg) {
                total7 = 35;
                size = "Regular";
            } else if (RadioGroup3 == R.id.large) {
                total7 = 50;
                size = "Large";
            }
        } else if (radioGroup2 == R.id.royal) {
            beverage = "Royal ";
            if (RadioGroup3 == R.id.reg) {
                total7 = 35;
                size = "Regular";
            } else if (RadioGroup3 == R.id.large) {
                total7 = 50;
                size = "Large";
            }
        } else if (radioGroup2 == R.id.coffee) {
            beverage = "Coffee ";
            if (RadioGroup3 == R.id.reg) {
                total7 = 30;
                size = "Regular";
            } else if (RadioGroup3 == R.id.large) {
                total7 = 50;
                size = "Large";
            }
        } else if (radioGroup2 == R.id.tea) {
            beverage = "Tea ";
            if (RadioGroup3 == R.id.reg) {
                total7 = 25;
                size = "Regular";
            } else if (RadioGroup3 == R.id.large) {
                total7 = 40;
                size = "Large";
            }
        }

        total8 = Integer.parseInt(quantitiy3.getText().toString());

        if (total8 >= 1) {
            total7 = total7 * total8;
        }
        result.append("\n" + total8 + " " + beverage + size + " (Total):                      " + total7);
        total1 = total2 + total5 + total7;
        result.append("\n Total Amount:                               " + total1);

        int radioGroup4 = radiogroup5.getCheckedRadioButtonId();
        radiobutton5 = findViewById(radioGroup4);
        if (radioGroup4 == R.id.cash) {
            payment = radiobutton5.getText().toString();
            totalamount = total1;

        } else if (radioGroup4 == R.id.debit) {
            payment = radiobutton5.getText().toString();
            totalamount = (total1 + (total1 * 0.05));

        } else if (radioGroup4 == R.id.credit) {
            payment = radiobutton5.getText().toString();
            totalamount = (total1 + (total1 * 0.1));
        }

        result.append("\nPayment thru:                    " + payment);
        result.append("\nTotal Amount:                          P " + totalamount);

        builder.setMessage(result.append("\n\nPay Now? "));
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                chkbx1.setChecked(false);
                chkbx2.setChecked(false);
                chkbx3.setChecked(false);
                chkbx4.setChecked(false);
                chkbx5.setChecked(false);
                chkbx6.setChecked(false);
                radiogroup1.clearCheck();
                radiogroup2.clearCheck();
                radiogroup3.clearCheck();
                radiogroup4.clearCheck();
                radiogroup5.clearCheck();
                quantitiy1.setText("");
                quantitiy2.setText("");
                quantitiy3.setText("");
                totalamount = 0;
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                totalamount = 0;
            }
        });

        AlertDialog alert = builder.create();
        alert.setTitle("Fast Food Ordering Form");
        alert.show();

    }


}