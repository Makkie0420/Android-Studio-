package com.jeyymsantos.gdscnubaliwag;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

public class UpdateActivity extends AppCompatActivity {

    ArrayAdapter<String> adapterSections;

    ProgressBar progressBar;
    Button btnCancel, btnUpdate;
    TextView txtEmail, tvError;
    RadioGroup rdSex;
    RadioButton rdMale, rdFemale;
    TextInputEditText txtFirstName, txtLastName, txtNewPassword, txtUsername;
    SharedPreferences sharedPreferences;
    String newUsername, newEmail, newPassword, id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        // Initialization

        btnUpdate = findViewById(R.id.btnUpdate);
        txtUsername = findViewById(R.id.txtupdateUsername);
        txtEmail = findViewById(R.id.txtupdateEmail);
        txtNewPassword = findViewById(R.id.txtupdateNewPassword);
        Intent i = getIntent();
        String name = getIntent().getStringExtra("username");
        String email = getIntent().getStringExtra("email");
        String password = getIntent().getStringExtra("password");
        id = getIntent().getStringExtra("id");
        txtUsername.setText(name);
        txtEmail.setText(email);
        txtNewPassword.setText(password);
        System.out.println(name);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newUsername = txtUsername.getText().toString();
                newEmail = txtEmail.getText().toString();
                newPassword = txtNewPassword.getText().toString();

                update();
            }
        });
    }

    private void update(){
        Toast.makeText(getApplicationContext(), "haasdas", Toast.LENGTH_SHORT).show();
            RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
            String url = "http://192.168.5.73/android/update.php";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            if (response.equals("success")) {
                                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                                i.putExtra("id1", id);
                                startActivity(i);

                                Toast.makeText(UpdateActivity.this, "Account Updated Successfully", Toast.LENGTH_LONG).show();
                                finish();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
                }
            }) {
                protected Map<String, String> getParams() {
                    Map<String, String> paramV = new HashMap<>();
                    paramV.put("id", id);
                    paramV.put("name", newUsername);
                    paramV.put("email", newEmail);
                    paramV.put("password", newPassword);
                    return paramV;
                }
            };
            queue.add(stringRequest);

    }
}