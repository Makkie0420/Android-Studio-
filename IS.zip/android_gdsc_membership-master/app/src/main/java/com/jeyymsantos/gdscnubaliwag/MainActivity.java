package com.jeyymsantos.gdscnubaliwag;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Button btnLogout, btnEdit, btnDelete;
    TextView txtFirstName, txtUsername, txtEmail, txtUsertype, txtUsername2;
    String usertyper = "", id;
    String id1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialization
        btnLogout = findViewById(R.id.btnLogout);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        txtUsername = findViewById(R.id.txtUsername);
        txtEmail = findViewById(R.id.txtEmail);
        txtUsername2 = findViewById(R.id.txtUsername2);
        txtEmail = findViewById(R.id.txtEmail);
        txtUsertype=findViewById(R.id.txtUsertype);
        // Checker / Validation
        Intent i1 = getIntent();
        String name = getIntent().getStringExtra("name");
        String email = getIntent().getStringExtra("email");
        String password = getIntent().getStringExtra("password");
        String id = getIntent().getStringExtra("id");
        id1 = getIntent().getStringExtra("id1");
        System.out.println(id1);
        System.out.println(name);
        int usertype = getIntent().getIntExtra("usertype", 0);
        if(usertype == 3){
            usertyper = "customer";
        }else{
            usertyper = "unknown";
        }
        txtUsername2.setText(name);
        txtEmail.setText(email);
        txtUsertype.setText(usertyper);
        // Display from Shared Preferences

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete();
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, UpdateActivity.class);
                i.putExtra("username", name);
                i.putExtra("email", email);
                i.putExtra("password", password);
                i.putExtra("id", id);
                startActivity(i);
                finish();
            }
        });
    }


    private void delete(){
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "http://192.168.5.73/android/delete.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(MainActivity.this, "Account Deleted Successfully", Toast.LENGTH_LONG).show();
                        if (response.equals("success")) {

                            Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(i);

                            Toast.makeText(MainActivity.this, "Account Deleted Successfully", Toast.LENGTH_LONG).show();

                            finish();

                        } else {
                            Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> paramV = new HashMap<>();
                paramV.put("id", String.valueOf(id));
                return paramV;
            }
        };
        queue.add(stringRequest);
    }
}