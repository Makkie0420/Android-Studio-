package com.example.pizza_app;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    private ToggleButton toggleButton1, toggleButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleButton1=(ToggleButton)findViewById(R.id.tbtn1);
        toggleButton2=(ToggleButton)findViewById(R.id.tbtn2);

    }



    public void click(View view) {
        LayoutInflater Li = getLayoutInflater();
        View layout = Li.inflate(R.layout.custom_toast,(ViewGroup) findViewById(R.id.customtoast));

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setView(layout);//setting the view of custom toast layout
        toast.show();
    }

    public void tbtn1(View view) {
        StringBuilder result = new StringBuilder();
        result.append("ToggleButton1 : ").append(toggleButton1.getText());
        //Displaying the message in toast
        Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_LONG).show();
    }

    public void tbtn2(View view) {
    }
}